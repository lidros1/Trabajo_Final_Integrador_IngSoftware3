package com.taller.automotor.models;

public class OrdenTrabajo {

    private String patente;
    private String dniCliente;
    private String marca;
    private String modelo;
    private String descripcion;
    private String estadoActual;
    private String tipoServicio;

    public OrdenTrabajo() {
    }

    public OrdenTrabajo(String patente, String dniCliente, String marca, String modelo, String descripcion, String tipoServicio) {
        this.patente = patente;
        this.dniCliente = dniCliente;
        this.marca = marca;
        this.modelo = modelo;
        this.descripcion = descripcion;
        this.tipoServicio = tipoServicio;
        this.estadoActual = "INGRESADOS";
    }

    public String getPatente() { return patente; }
    public void setPatente(String patente) { this.patente = patente; }

    public String getDniCliente() { return dniCliente; }
    public void setDniCliente(String dniCliente) { this.dniCliente = dniCliente; }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getEstadoActual() { return estadoActual; }
    public void setEstadoActual(String estadoActual) { this.estadoActual = estadoActual; }

    public String getTipoServicio() { return tipoServicio; }
    public void setTipoServicio(String tipoServicio) { this.tipoServicio = tipoServicio; }
}