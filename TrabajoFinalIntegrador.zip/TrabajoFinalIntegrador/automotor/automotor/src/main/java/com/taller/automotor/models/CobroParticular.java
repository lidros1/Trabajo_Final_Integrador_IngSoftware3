package com.taller.automotor.models;

public class CobroParticular implements EstrategiaCobro {
    @Override
    public double calcularMonto(double montoBase) {
        return montoBase; // El particular paga el 100%
    }
}