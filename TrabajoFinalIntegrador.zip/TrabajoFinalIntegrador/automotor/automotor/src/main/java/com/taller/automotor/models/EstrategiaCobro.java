package com.taller.automotor.models;

public interface EstrategiaCobro {
    double calcularMonto(double montoBase);
}