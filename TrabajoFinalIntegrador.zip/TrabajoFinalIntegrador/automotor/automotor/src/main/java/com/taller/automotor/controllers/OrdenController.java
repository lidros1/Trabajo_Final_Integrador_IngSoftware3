package com.taller.automotor.controllers;

import com.taller.automotor.models.OrdenTrabajo;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ordenes")
public class OrdenController {

    // Usamos una lista en memoria que simula la Base de Datos perfectamente
    private static List<OrdenTrabajo> baseDeDatos = new ArrayList<>();

    @PostMapping("/crear")
    public OrdenTrabajo generarNuevaOrden(@RequestBody Map<String, String> datos) {
        OrdenTrabajo nuevaOrden = new OrdenTrabajo(
                datos.get("patente"),
                datos.get("dniCliente"),
                datos.get("marca"),
                datos.get("modelo"),
                datos.get("descripcion"),
                datos.get("tipoServicio")
        );

        baseDeDatos.add(nuevaOrden);
        return nuevaOrden;
    }

    @GetMapping("/listar")
    public List<OrdenTrabajo> obtenerTodas() {
        return baseDeDatos;
    }

    @PutMapping("/editar/{patente}")
    public OrdenTrabajo editarOrden(@PathVariable String patente, @RequestBody Map<String, String> datosActualizados) {
        for (OrdenTrabajo orden : baseDeDatos) {
            if (orden.getPatente().equalsIgnoreCase(patente)) {
                orden.setEstadoActual(datosActualizados.get("estadoActual"));
                orden.setDescripcion(datosActualizados.get("descripcion"));
                return orden;
            }
        }
        throw new RuntimeException("Orden no encontrada");
    }
}