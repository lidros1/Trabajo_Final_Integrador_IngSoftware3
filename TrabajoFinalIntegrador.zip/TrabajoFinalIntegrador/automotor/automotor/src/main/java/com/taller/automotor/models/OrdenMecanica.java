package com.taller.automotor.models;

public class OrdenMecanica extends OrdenTrabajo {

    public OrdenMecanica(String patente, String dniCliente, String marca, String modelo, String descripcion) {
        // Le pasamos todos los datos al padre, y agregamos "MECANICA" al final
        super(patente, dniCliente, marca, modelo, descripcion, "MECANICA");
    }
}