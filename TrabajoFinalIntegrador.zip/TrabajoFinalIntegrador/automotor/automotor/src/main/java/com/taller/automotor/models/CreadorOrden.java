package com.taller.automotor.models;

public class CreadorOrden {

    public static OrdenTrabajo crearOrden(String tipo, String patente, String dni, String marca, String modelo, String desc) {
        if (tipo.equalsIgnoreCase("MECANICA")) {
            return new OrdenMecanica(patente, dni, marca, modelo, desc);
        }
        // Si más adelante agregás otras clases como OrdenChapa, lo ponés acá.
        // Si no es ninguna de las esperadas, creamos una orden genérica.
        return new OrdenTrabajo(patente, dni, marca, modelo, desc, tipo);
    }
}